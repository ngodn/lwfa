# lwfa investor deck

Source markdown for the slide build. One `##` heading per slide, images
referenced from `assets/`. Structure follows the Sequoia 10-slide format,
closing on what we are looking for rather than a fixed ask. Keep each slide to what fits on a screen; the notes under
"Speaker note" are for the presenter, not the slide.

**Notes for the slide builder (Claude Design):**

- Always research online first; do not rely on your own model directly when
  thinking. Every number in this deck is sourced in the appendix; if you add
  or change a figure, verify it online before it goes on a slide.
- Never write or produce anything that reads like an AI. No em dashes, no
  stock AI phrasing, no formulaic structure. Plain, natural, human wording
  only.
- Ask for clarification whenever in doubt instead of guessing.

---

## 1. lwfa

**Work and play from any screen. The computer stays where you put it.**

A desktop that lives on hardware you control and opens in any browser:
phone, tablet, personal laptop. No app to install, nothing stored on the
device.

*Logo: assets/brand/svg/mark-on-dark.svg*

Speaker note: one sentence and stop. "We turn any machine into a desktop you
can open like a website, and it is already built."

---

## 2. The problem

**Company data lives on employee laptops. Powerful computers sit chained to
desks.**

- Every laptop a company hands out is company data walking out the door:
  lost devices, leavers keeping copies, contractors on unmanaged machines.
- Onboarding is shipping hardware; offboarding is hoping it comes back.
- The tools that exist are 20 years old: VDI licensing alone lists at
  `$30-50`/user/mo (Citrix) before infrastructure and operations, and remote
  desktop apps stream a fixed rectangle of screen that fights every device
  it lands on.
- Meanwhile the machines with real power, workstations, GPU rigs, lab PCs,
  are only usable by the person sitting in front of them.

Speaker note: two audiences in one problem. Companies want control; people
want their computer to follow them.

---

## 3. The solution

**A desktop served as a web page.**

- Open a URL, sign in, and the full desktop is there: apps, files, games,
  everything running on the remote machine.
- Nothing to install and nothing retained on the device. Close the tab and
  the data never left the server.
- Each application window streams individually, so the desktop re-arranges
  itself to fit a phone, a tablet, or a monitor, instead of shrinking a
  distant screen.
- Works today on an iPad over normal wifi, including 3D games with an
  on-screen controller that games treat as real hardware.
- The endpoint bar is deliberately low: any device with a modern browser.
  A budget tablet, a used iPad, or the PC an institution already owns all
  work, because the computing happens on the server.

*Visual: assets/product-desktop-management.png. An iPad session with the
window and workspace controls open: the desktop being arranged from the
device holding it.*

Speaker note: the differentiator is "a desktop, not a screen-share".
Everything else in the market ships a rectangle.

---

## 4. The product is built, shipped and used daily

- Working software, not a prototype: versioned public releases, one-file
  installer, open source.
- In daily production use: a gaming PC driven entirely from an iPad,
  including AAA games under Proton at high visual quality over wifi.
- Hardware video per window (H.264/HEVC), Opus audio, adaptive bitrate
  driven by live network measurement, sessions that survive wifi drops
  without losing state.
- Built-in account system: named users, watch-only or full control, per-app
  permissions enforced server-side.

*Visuals: assets/product-game-controller.png (a AAA game with the
on-screen controller and its settings panel) and
assets/product-office-work.png (the app launcher opening LibreOffice, an
ordinary work session). Both are real iPad captures of the product.*

Speaker note: this is the de-risking slide. Most decks promise engineering;
this one demonstrates it. Offer the live demo here.

---

## 5. Why now

- **Browsers just became capable.** Chrome shipped the key APIs (hardware
  video decode in the page) in late 2021; Safari on iPad only completed
  them in 2025. The iPad experience this product is built around was
  impossible until now, which is why every incumbent still ships an
  installed client.
- **Hybrid work is permanent**, and BYOD is how SEA workforces actually
  operate: personal devices everywhere, corporate laptops nowhere.
- **Data sovereignty is policy now.** Governments and regulated industries
  in the region increasingly require data on infrastructure they control,
  not a US hyperscaler. A desktop that keeps data in-country on owned
  hardware is aligned with where regulation is going.
- **Cloud gaming proved the demand** and Asia Pacific leads it with ~46% of
  the global market.

Speaker note: the browser-capability point is the honest moat-in-time. The
incumbents built native clients because browsers could not do this; we built
for the browser because now they can.

---

## 6. Market

| Segment | Size | Growth |
|---|---|---|
| Desktop as a Service (business and public sector) | `$4.3B` (2025) | to `$6B` by 2029 |
| Cloud gaming (consumer) | `~$6B` (2026) | 25-40% CAGR, `$30B+` by early 2030s |
| Asia Pacific share of cloud gaming | ~46% | fastest-growing region |

Our entry market is Malaysian institutions: universities (replace computer
labs with browser desktops on students' own devices), government agencies
(data stays in-country on owned hardware), and GLC/enterprise via a local
distribution partner. Thousands of seats per institution, procurement-driven,
low churn.

*Slide footer, small text: Sources: industry DaaS roundups 2026; Grand View
Research and Mordor Intelligence cloud gaming reports 2026.*

Speaker note: TAM is the two categories; SAM is SEA institutional desktops;
SOM is the first three Malaysian pilots. Universities are the beachhead: IT
adoption is culturally easy there, and one campus is thousands of seats.

---

## 7. Business model

Software plus managed seats, priced per user per month. Representative
seat economics at target scale:

| Tier | Price | Infra cost | Gross margin |
|---|---|---|---|
| Business / public sector work seat | `$23` | `~$11` | **~50%** |
| Consumer work and study | `$12` | `~$6` | ~50% |
| Consumer gaming, shared GPU | `$35` | `~$28` | ~20% |
| Dedicated GPU seat | `$55` | `~$40` | ~27% |

- Work seats are the margin engine: ~8 users share one server's integrated
  GPU. Dedicated GPUs are only for gaming and pro tiers.
- No per-seat Microsoft licensing, a cost every Windows-based competitor
  carries.
- No hardware on our balance sheet: bundled devices go through the
  distribution partner, and existing PCs become terminals via a boot image.

*Slide footer, small text: Infrastructure priced on published SEA bare-metal
rates, in-region for latency, 2026. Detail in appendix.*

Speaker note: anchor against Windows 365 at `$28-66`/user/mo; we undercut
with better margins because there is no Windows tax. If pressed on the infra
number: in-region Singapore/Malaysia bare metal is `$100-150`/mo per 8-seat
box, roughly twice the European floor, and that is what `~$11`/seat carries;
owned hardware in Malaysian colo improves it at scale. If asked who buys the
tablet: nobody has to (appendix).

---

## 8. Competition

| | Browser-native | Real desktop | Per-window / responsive | Games | Price anchor |
|---|---|---|---|---|---|
| Windows 365 / AWS WorkSpaces | No, web access is a fallback | Yes | No | No | `$28-75`/mo |
| Citrix / Omnissa VDI | No, HTML5 client is secondary | Yes | No | No | `$30-50`/mo licence + infra |
| Kasm (browser Linux) | Yes | Container apps | No | No | Quote-only |
| GeForce NOW | Partial (browser on iOS) | No, catalogue only | No | Yes | `$20`/mo |
| Shadow | No, web client in beta | Yes | No | Yes | `$34-55`/mo |
| **lwfa** | **Yes, browser is the product** | **Yes** | **Yes** | **Yes** | `$12-55`/mo |

The moat: a purpose-built per-window streaming engine nobody else in the
table has, in an open-source codebase governments can audit.

*Slide footer, small text: Prices from vendors' published pricing, 2026.*

Speaker note: if asked "why can't Microsoft do this": they are structurally
committed to the Windows license and the installed client; our advantage is
what they cannot copy without cannibalising. Worth saying aloud, not
printing: this category has already killed a funded competitor. Shadow's
operator went bankrupt in 2021 on 1:1 GPU economics, and our model is built
on the work-seat margins they never had. Knowing exactly why the last one
died is the credibility line of the meeting.

---

## 9. Go to market

**Partner-led institutional sales, consumer as the funnel.**

1. **Pilot (months 1-9):** two or three Malaysian institutions through a
   local distribution partnership currently in discussion, with reach into
   government and a Berhad company. Universities first: a
   computer-lab replacement pilot is a contained, measurable win with
   thousands of follow-on seats. The pilot pitch is "zero new hardware":
   students use their own devices and the existing lab PCs become
   terminals, so the pilot's capital cost is nearly nothing.
2. **Land and expand (months 9-24):** convert pilots to per-seat contracts;
   the distribution partner carries procurement; reference customers open
   agencies and GLCs.
   Candidate infrastructure partner: YTL's Johor data centre park
   (operational, NVIDIA-partnered, Equinix-connected, public-sector
   positioned). Hosting seats there makes "your data stays in Malaysia, in
   a Malaysian-owned datacenter" literal, which is the sentence sovereign
   procurement wants to hear. Relationship exploratory, stated as such.
3. **Consumer self-serve** runs in parallel at near-zero sales cost: the
   open-source community is the top of the funnel, paid hosted seats are
   the conversion.

Speaker note: the partner is the slide, and honesty about its status
matters: relationships identified, partnership not yet signed. When it is
signed, name it here; local distribution into government is the thing a
foreign competitor cannot replicate.

---

## 10. Traction

- Product shipped: public releases (v1.0.x), one-file installer, working
  upgrade path.
- In daily production use by the founder: work and AAA gaming from an iPad
  over ordinary wifi.
- Open source with the full engineering record public.
- Built end to end by one engineer, which is the capital-efficiency story
  of this deck.

Speaker note: pre-revenue, and say so plainly before anyone asks. The
traction claim is velocity and a working product, not users. Then show the
demo again.

---

## 11. Roadmap to first revenue

| Quarter | Milestone |
|---|---|
| Q1 | Headless backend: engine runs on bare cloud servers, no host desktop |
| Q1 | Intel/AMD hardware encode (VAAPI): the enabler for low-cost work seats on iGPU servers |
| Q1-Q2 | Multi-seat provisioning: one server, many isolated user sessions |
| Q2 | SSO and audit logging (the two features procurement always asks for) |
| Q2-Q3 | First university pilot live |
| Q2-Q3 | Boot-to-lwfa terminal image, so existing lab PCs are the clients |
| Q4 | Pilots convert to paid seats; consumer hosted beta |

Speaker note: nothing on this list depends on unproven technology. The
first two items are scoped in the public architecture docs; the rest is
ordinary product engineering.

---

## 12. About the founder

- **Denny Aprilio P**, senior software engineer.
  Designed, built and shipped the entire product alone. It is public,
  versioned, and in daily use running his own desktop and games.
  *Photo: assets/founder-denny.jpeg*
- **The open seat:** a business counterpart for the institutional side:
  pilots, procurement, partnerships. This deck is part of finding that
  person.

Speaker note: at this stage the team slide is the bet, so it has to be
true: one technical founder, whole product, and a named gap. Naming the
gap is not weakness; it tells the room exactly what kind of help converts
interest into a pilot, and the people this deck reaches through are
precisely the ones who might fill or refer it.

---

## 13. What we are looking for

The product is built. What it needs next is not code:

1. **A pilot partner.** One university or agency willing to trial browser
   desktops on a contained scope: a lab, a department, a semester. We bring
   the software and run it; the pilot defines the real numbers.
2. **A distribution conversation.** A local partner with reach into the
   institutions above, structured around the pilot.
3. **An investor conversation, sized honestly.** We have a working unit
   economics model (appendix) but will not put a raise amount on a slide
   before a pilot and a partner make the budget real. If those land, the
   round is sized to a concrete plan, not a template.

Speaker note: this is deliberate. A solo technical founder claiming "give
us `$750k` and we deliver 2,000 seats" is a promise nobody here can keep
yet, and the people in this room will know it. The credible version is:
the technical risk is retired, the demo is live, and the next step costs a
pilot, not a round. Investors who want in early can shape the round; that
is an advantage to offer, not a weakness to hide.

---

## Appendix: numbers backup (build as hidden backup slides, or omit; never
presented in the main flow, exists for Q&A)

- Unit economics detail: see positioning-and-unit-economics.md and
  market-segments.md in this directory.
- Illustrative funding model, for the "how much would you need" question:
  a 24-month plan with three Malaysian hires works out near `$750k`
  (roughly 55% payroll, 15% pilot infrastructure, 10% compliance, 10%
  sales, 10% buffer), and 2,000 work seats at `$23` is `~$550k` ARR. These
  are model outputs from the docs above, not commitments; the real budget
  gets built with a pilot partner.
- DaaS market `$4.3B` to `$6B` 2029: apps4rent industry roundup 2026.
- Cloud gaming `~$6B` 2026, 25-40% CAGR, APAC ~46% share: Grand View
  Research, Mordor Intelligence, market reports 2026.
- Windows 365 `$28-66`/user/mo, AWS WorkSpaces `$25-75` plus fees: public
  pricing.
- Citrix licensing `$30-50`/user/mo list, before infrastructure and
  operations: venn.com Citrix pricing guide, getnerdio TCO analysis, 2026.
- Browser web clients of competitors (Windows 365 web access, Citrix HTML5,
  GeForce NOW in browser, Shadow web beta) exist as secondary access paths;
  the comparison column claims browser-*native*, not browser-*absent*.
- Shadow operator bankruptcy 2021 on 1:1 GPU economics: Datacenter
  Dynamics, TechCrunch, April 2021.
- Kasm, Inuvika pricing: public pages, 2026.
- Device-as-a-Service market `$97B` (2025) to `$361B` (2034), HP/Dell/Lenovo
  led: Precedence Research 2026. Cited as the reason endpoints go through
  the hardware partner rather than our balance sheet.
- Endpoint floor: WebCodecs in Safari 16.4+/Chrome; budget Android tablets
  `$185-250` new (Tom's Guide 2026); decode is hardware in any modern SoC.
- Work-seat server sizing: ~8 concurrent seats per modern 8-core box with
  an iGPU media engine, sized per *concurrent* seat because business use
  peaks together, 9-to-5. Intel/AMD iGPU encoders have no per-session cap,
  unlike consumer NVENC's 8. Depends on the VAAPI encoder path on the
  roadmap; the engine is NVIDIA-only today, stated on slide 11 rather than
  hidden.
- In-region server costs (latency requires hosting within ~30ms of users):
  OVHcloud Singapore bare metal from S`$135`/mo, other Singapore providers
  from `$99`; Malaysian dedicated from RM327-447 for older hardware, modern
  boxes higher; Cyberjaya colocation ~RM450/mo per 1U with 100Mbps
  committed, so streaming bandwidth is an added line. The European floor
  (Hetzner EUR 46) is cited only as the global reference; it is 180ms from
  Malaysia and unusable for this product.
- YTL: AI data centre operational in Kulai, Johor (GB200s, NVIDIA Exemplar
  Cloud status, Equinix interconnect, public-sector positioning; The Edge
  Malaysia, DCD, 2025-2026). Their accelerators are AI-shaped, not
  desktop-streaming-shaped, so the candidate partnership is colocation,
  power and government channel, not GPU rental.

Anticipated Q&A: "who provides the tablet?" Nobody has to. The device the
user already owns is the design target; bundled devices are the partner's
hardware business, not ours; and old institutional PCs are converted to
terminals by a boot image, which is software we sell, not hardware we
finance.

## Asset inventory for the slide build

| File | Use on |
|---|---|
| assets/brand/svg/mark-on-dark.svg, mark-on-light.svg | Title, footers |
| assets/brand/ (full kit, wordmarks, favicons) | Anywhere |
| assets/product-desktop-management.png | Slide 3, the desktop arranged from an iPad |
| assets/product-game-controller.png | Slide 4, game + on-screen controller |
| assets/product-office-work.png | Slide 4, work session |
| assets/founder-denny.jpeg | Slide 12, founder photo |
| assets/competitors/microsoft.svg | Slide 8, Windows 365 row |
| assets/competitors/windows11.svg | Slide 7, the "Windows tax" point |
| assets/competitors/aws.svg | Slide 8, WorkSpaces row |
| assets/competitors/citrix.svg | Slide 8, VDI row |
| assets/competitors/kasm.png | Slide 8, Kasm row |
| assets/competitors/geforce-now.svg, nvidia.svg | Slides 5-6 and 8, cloud gaming |
| assets/competitors/steam.svg, proton.svg | Slide 4, the gaming proof |
| assets/competitors/linux-tux.svg | Slide 7, the no-license-fee point |

Competitor marks are the companies' own official logos (Wikimedia Commons
and their published assets), used nominatively in a comparison, which is
standard pitch-deck practice. Shadow and Omnissa logos were not cleanly
fetchable; the slide tool can render those rows as text, which also reads
fine.

The three product captures are staged iPad screenshots of the real product
(status bar shows an ordinary iPad on wifi, which is itself part of the
proof). If any slide wants a tighter crop, crop from these originals rather
than re-shooting.
