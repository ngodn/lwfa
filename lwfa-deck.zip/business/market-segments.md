# Two products, one engine: B2B managed desktops and the consumer cloud PC

Private notes, 2026-08-05. Follows positioning-and-unit-economics.md, which
covered the consumer side; this adds the B2B segment and compares them.

## The short version

The B2B version of lwfa is a category that already exists and already pays:
Desktop as a Service, `$4.3B` in 2025 heading to `$6B` by 2029, with Microsoft
charging `$28-66/user/mo` for Windows 365 and AWS `$25-75` for WorkSpaces. The
segment's economics are better than consumer gaming in every line: CPU-only
seats, employer-paid, low churn, tens of seats per sale instead of one.

The catch is that enterprises buy governance and trust, not streaming
quality. Half of what they need lwfa already has (accounts, permissions,
watch-only sessions, browser-only clients). The other half is real work:
SSO, audit logs, an admin console, per-user session isolation, and
eventually a SOC 2 report.

## What B2B buyers are actually paying for

Not the desktop. The control around it:

- **Data never leaves the datacenter.** A contractor in another country works
  on company code and files without any of it existing on their laptop. This
  is the whole pitch for outsourcing, agencies and IP-sensitive work.
- **Onboarding and offboarding in minutes.** A seat is created and revoked
  centrally. No laptop shipping, no wiping, no "did they keep a copy".
- **BYOD without endpoint management.** The employee's own device only ever
  runs a browser. No MDM enrollment, no client software to police.
- **Least privilege.** Who can run what, who can only watch.

lwfa's existing feature set reads like it was designed against this list,
because half of it was built for the family-and-friends case that happens to
rhyme: named accounts in the engine, watch-only vs interact modes,
**per-application launch permissions enforced engine-side**, one driver with
others watching (which is literally supervised support and training), and a
client that is nothing but a URL. The browser-only client is the sharpest
B2B differentiator: Citrix, Omnissa and WorkSpaces all push installed
clients; the closest browser-native analogue is Kasm.

## The competitive map

| | Model | Price anchor | Weakness lwfa exploits |
|---|---|---|---|
| Windows 365 | Windows VM per user | $28-66/user/mo | Price includes Windows tax; clunky over high latency; no watch/handoff |
| AWS WorkSpaces | Windows/Linux VDI | $25-75 + hidden fees | Complexity, hidden SAL and app fees, AWS-grade UX |
| Citrix / Omnissa | Enterprise VDI | $100+ all-in | Cost, weight, legacy clients; SMEs priced out |
| Kasm Workspaces | Containerised Linux desktops in browser | Free to 5 sessions, then quote | Closest analogue. Container apps, not a real desktop session; no gaming story; VNC-class streaming |
| Inuvika OVD | Linux app delivery | $9.50/concurrent user | Sets the floor price for Linux seats |

Kasm is the one to study seriously: browser-native Linux desktops, container
isolation, and it demonstrably fills the gap between enterprise VDI and
nothing. lwfa's edge over it is the streaming quality (per-window hardware
video vs VNC-style capture), the desktop being a real session rather than a
container app, and the same engine covering the consumer/gaming story Kasm
cannot touch.

## Where lwfa wedges in first

Not "replace Citrix at a bank". The credible first customers are SMEs that
are already Linux-friendly and latency-sensitive:

1. **Dev workstations.** A full GUI Linux desktop in the browser, per
   developer. Codespaces, Gitpod and Coder deliver editors, not desktops;
   the moment a team needs a browser, a GUI debugger, or a design tool next
   to the editor, they are back on laptops. lwfa gives the whole desktop
   with the repo never leaving the server.
2. **Agencies and outsourced teams.** The IP-containment pitch, priced under
   Windows 365, on machines the agency controls.
3. **Support and ops teams.** The watch-only and take-control model is
   supervision and training out of the box.

## B2B unit economics

A work seat needs a shared GPU, not a dedicated one: a server CPU's
integrated GPU renders office workloads and hardware-encodes many sessions
at once (no per-session cap on Intel/AMD media engines). This depends on
the engine's VAAPI encode path, the roadmap's next item; today's engine is
NVENC-only and would fall back to JPEG on these boxes.

Location matters as much as hardware: an interactive desktop needs the
server within ~30ms of the user, so Malaysian customers mean SEA hosting.
The European floor (Hetzner EUR 46/mo for an ideal 8-seat box) is a
reference only; in-region equivalents run `$100-150`/mo (OVH Singapore from
S`$135`, SG providers from `$99`, Malaysian locals RM327-447 for older
hardware). Cyberjaya colocation is ~RM450/mo per 1U but with 100Mbps
committed, so streaming bandwidth is an extra line. Net: `$10-15`/seat
in-region rather than the `$6-7` a European box suggests, improving with
owned hardware in Malaysian colo at scale. YTL's Johor park (operational,
NVIDIA-partnered, Equinix-connected, public-sector positioned) is the
natural colo candidate and doubles as the sovereignty story; their GB200
accelerators are AI-shaped, so the partnership shape is space, power and
channel, not GPU rental. Per-seat, at scale:

| Line | $/mo |
|---|---|
| Share of a shared CPU box (8-10 seats) | 4-6 |
| Storage slice | 1 |
| Bandwidth | 1-2 |
| Support (B2B, heavier per-seat but amortised across the account) | 2-3 |
| **Infra + support total** | **8-12** |

At `$20-25/seat` (undercutting Windows 365 by selling Linux honestly), gross
margin is 55-65%. B2B adds costs consumer does not have: sales time per
account, security questionnaires, and eventually SOC 2 (roughly `$30-80k` and
months of process the first time). It removes costs consumer has: CAC per
single user, card-fraud, and most churn, since B2B seats renew until the
company changes tooling.

Contract shape matters more than list price: 20 seats at `$22` is `$440/mo` from
one sales conversation, roughly what 15 consumer gaming subscribers yield
with far less support noise and no Friday-night GPU contention.

## Consumer, unchanged but sharpened by contrast

The consumer product stays as the other doc describes: personal cloud PC,
games and work in one strip, `$35` shared / `$55` dedicated tiers, ~20% gross on
gaming seats, the work tier at `$10-15` carrying the margin. The B2B segment
makes the roadmap overlap visible: both need the TTY/headless backend,
provisioning, and built-in TLS. Nothing on the B2B-only list (SSO, audit,
admin console) blocks the consumer product, so the sequencing question is
which segment pays for the shared foundation first.

## What B2B requires that does not exist yet

In rough dependency order:

1. **Per-user session isolation.** Today one engine is one desktop. B2B means
   an engine per user on shared boxes, which is the TTY/headless backend
   plus provisioning. Same prerequisite as everything else.
2. **Built-in or automated TLS**, because "install our nginx template" does
   not survive procurement.
3. **SSO** (OIDC first, SAML for bigger fish) mapping to the existing
   accounts model.
4. **Audit logging.** Who connected, from where, what was launched, when.
   The engine already sees every one of these events; it just does not
   record them.
5. **An admin console.** Seats, usage, permissions across many engines. The
   Access panel is the single-engine seed of it.
6. **SOC 2**, when a deal actually demands it, not before.

## Endpoints: the device question, settled

Every seat needs a client device, and the temptation is to sell one. The
numbers say no. Device-as-a-Service is a `$97B` market precisely because it
is a financing-and-logistics business, owned by HP, Dell and Lenovo at
5-15% hardware margins against our 55-65% software margins. Holding tablet
inventory is how the runway dies.

What we do instead, in order of margin:

1. **Design for the device they own.** The client floor is any modern
   browser: used iPads, `$185-250` Android tablets, existing laptops. Say
   this loudly; a low endpoint floor is the thin-client pitch.
2. **Boot-to-lwfa image for existing PCs.** A USB/PXE image that turns an
   institution's old machines into terminals. Zero inventory, pure
   software, and it makes the university pilot a "zero new hardware" story.
3. **Bundled devices through the distribution partner.** Hardware is the
   Berhad channel's business; procurement gets one contract; we take the
   seats and optionally a referral share. Never on our balance sheet.

## Honest risks

- **Windows apps are solvable technically, hard legally.** The WinBoat
  pattern (real Windows in KVM, FreeRDP RemoteApp presenting each program as
  its own window) fits lwfa unusually well: every RemoteApp window becomes
  its own stream in the strip next to native Linux windows, per-window model
  intact, no GPU passthrough needed for Office-class apps. The wall is
  licensing, not engineering. SPLA does not permit offering Windows client
  desktops as a service; the compliant B2B path is the customer bringing
  Windows E3/E5/VDA per-user licenses under Microsoft's Flexible
  Virtualization benefit (2022), which suits companies that have Microsoft
  365 E3 anyway. For consumers there is no clean way to license a hosted
  Windows VM at all, which is the gray area Shadow has lived in for years.
  So: sell "Linux desktop that also runs your Windows apps" to B2B with
  bring-your-own-license, and keep consumer marketing away from Windows
  promises. A Windows VM also roughly doubles a seat's RAM and disk, so
  price those seats accordingly.
- **Kasm exists and is mature.** The differentiation is real (streaming
  quality, real sessions, gaming DNA) but has to be demonstrated, not
  asserted.
- **B2B sales is a job.** Nobody buys 20 seats from a GitHub README. This
  segment costs founder time in calls and paperwork, which trades directly
  against engineering.
- **One engine serving both segments is leverage and risk.** Every
  enterprise feature added must not encrust the consumer product; the
  account model staying engine-side and optional is the pattern to hold.

## Sources

- DaaS market size and provider comparison: apps4rent.com top DaaS providers
  2026; venn.com DaaS pricing models
- Windows 365 from `$28/user/mo`: apps4rent.com
- AWS WorkSpaces `$25-75` plus RDS SAL and app fees: venn.com, graphon.com,
  aws.amazon.com/workspaces/desktop-as-a-service/pricing
- Kasm Workspaces model and community edition: capterra.com,
  conversiongems.com review
- Inuvika OVD `$9.50`/concurrent user; Linux cutting VDI cost up to 60%:
  softwareworld.co alternatives roundup
- WinBoat architecture: github.com/TibixDev/winboat, windowsforum.com writeups
- Windows client hosting licensing: samexpert.com on SPLA,
  microsoft.com/licensing Windows 11 virtual desktop guidance
- Consumer-side numbers: positioning-and-unit-economics.md in this directory
