# lwfa as a service: positioning and unit economics

Private notes, 2026-08-05. Not part of the repository; the directory is
gitignored. Numbers are estimates grounded in public pricing and one public
bankruptcy, gathered while thinking about whether a hosted lwfa is a business.

## The one-line conclusion

Sell "your personal cloud PC", not "cloud gaming". Gaming seats at Shadow's
price point make ~20% gross margin at best and carry all the capacity risk.
Work seats make 50%+ with none of it. Gaming is the marketing; productivity is
the profit. lwfa is unusually well shaped for that split because one session
holds both.

## Why not the GeForce NOW fight

GFN sells access to a catalogue at `~$20/mo`, subsidised by NVIDIA's position.
It deliberately is not a PC: no files, no mods, no installs, session wiped.
Competing with it on price is unwinnable; a rented RTX 3060 alone eats the
subscription (vast.ai math below).

The product lwfa actually is maps to Shadow's category: a computer that
happens to live elsewhere. Your library, saves, mods, files, plus a terminal
and a browser. That category tolerates `$30-55/mo` because it is "my machine".

What lwfa has that Shadow does not:

- No client app. A URL that becomes a PWA. Any iPad, Chromebook, borrowed
  laptop.
- A desktop, not a screen. Per-window streaming reflows to the viewport;
  everyone else ships a fixed rectangle of remote monitor.
- Games and work in one strip. The "personal PC" claim made literal.
- Multi-device with roles: one drives, others watch, control handed over
  explicitly. Accounts with per-app permissions.
- Linux, so no Windows SPLA license (`~$8-10/user/mo` that Shadow pays and we
  would not). This single line item is most of the gaming tier's margin.

What it lacks, honestly:

- Anti-cheat multiplayer titles are a wall (Proton), the same wall every
  non-Windows competitor hits.
- Hosting must be VMs or bare metal: the engine needs /dev/uinput and a
  session compositor, so cheap container marketplaces (vast.ai) are out until
  a TTY/headless backend exists. That backend is already on the roadmap for
  its own reasons.

## The anchor fact

Blade, Shadow's operator, went bankrupt in March 2021 with ~100,000 paying
subscribers and over `$100M` raised. The 1:1-GPU cloud PC at consumer pricing
has already failed once at scale. Today's Shadow survives at `$34-38` base and
`~$55` premium under Octave Klaba, who owns his own datacenters. Treat that as
the floor of what the category costs to run.

## Unit economics at `$35/mo`

### Model A: rented dedicated GPU, 1:1. Dead.

Cheapest serious rental is Hetzner GEX44 at EUR 184/mo. Lose `~$165`/user
before support exists. Renting retail can never work; margin requires owning
hardware.

### Model B: owned hardware in colo, 1:1. The Shadow model, and it loses.

| Line | $/mo | Basis |
|---|---|---|
| Box amortised | 27 | ~$880 build (7500F, RTX 4060, 32GB, 2TB) over 36mo, +10% spares |
| Colo space + power | 40-55 | ~$300 quarter rack across 8 boxes, 110kWh at $0.15 |
| Bandwidth | 1-3 | 95th percentile transit, ~550GB/user at 20Mbit/s |
| Support | 2.5 | ~7% of revenue |
| Payments | 1.35 | 2.9% + $0.30 |
| CAC amortised | 3 | $40 acquisition over ~14mo lifetime |
| **Total** | **75-92** | Loses $40-57/user. This is why Blade died. |

### Model C: owned hardware, time-shared 4:1, persistent storage per user.

The GPU is yours while the session runs; the disk always is.

| Line | $/mo |
|---|---|
| Box + colo, divided by 4 | 17-20 |
| Per-user storage slice | 1 |
| Bandwidth | 2 |
| Support, payments, CAC, fraud buffer | 7.5 |
| **Total** | ~28, so ~20% gross at $35 |

The ratio is the product risk: 4:1 needs peak concurrency under 25%, and
gaming peaks in the evening at 15-25%. Some Friday night somebody's
"personal PC" has a queue, which is the one thing the positioning promised
away. Resolve it by selling the ratio honestly as tiers: shared at `$35`,
dedicated at `$55`+. That is exactly Shadow's ladder, so the market already
understands it.

### The tier that actually makes money

A work seat needs no discrete GPU. A shared CPU box takes 8-10 users at
`$4-6`/user infra. At `$10-15/mo` that is 50-60% gross. Shadow validating the
segment is Shadow Essential at `$9.99`. One lwfa install serves both tiers,
which is the structural advantage: the strip holds Stellar Blade next to a
terminal, and the billing tier is just which box the session lands on.

## Fixed costs and breakeven

Everything above is contribution margin. Lean payroll (2 engineers plus
infra-ops) is `~$30k/mo`. At `~$7` contribution per gaming user, breakeven is
roughly 4,000-5,000 subscribers, fewer as the mix skews to work seats. Below
that it is a founder-run side business, which is also exactly what the
current daily-driven setup already is.

## The vast.ai aside that started this

Renting a marketplace RTX 3060 at `$0.055/hr`: `~$40/mo` at 24/7, `~$7/mo` at
4h/day plus `$8-30` storage plus bandwidth at host-set rates (`$0.01-0.10/GB`;
a 20Mbit stream is 9GB/hour, so 4h/day is ~1.1TB/mo, `$11-110`). Fine for a
personal experiment, unusable as a service substrate: containers (no uinput,
no session), monthly eviction (max duration), and egress pricing that can
dwarf the GPU.

## What would have to be true before taking this seriously

1. TTY/headless backend, so the engine owns a display on a rented VM or bare
   metal with no host compositor. Already wanted for other reasons.
2. Provisioning: image a box, create an account, hand out a URL. The
   installer is most of this already.
3. Concurrency management for the shared tier: parking sessions, queueing,
   the 45-second grace generalised to "your PC is being resumed".
4. A hardware partner or colo relationship, since owning boxes is the only
   model with margin.
5. A decision about anti-cheat honesty in marketing: list what does not work
   before customers discover it.

## Sources

- Blade bankruptcy: datacenterdynamics.com, 9to5google.com (April 2021)
- Shadow acquisition by Klaba: techcrunch.com (April 2021)
- Shadow pricing 2026: shadow.tech/us/shadowpc/offers, tech-insider.org
- Shadow Essential: shadow.tech/us/blog/shadow-essential
- Hetzner GEX44: hetzner.com/dedicated-rootserver/gex44
- vast.ai listing observed 2026-08-05: 1x RTX 3060, `$0.055/hr` plus bandwidth
